window.addEventListener('DOMContentLoaded', function() {
  var image = document.getElementById('random-image');
  var container = document.querySelector('.container');
  
  var randomX = Math.random() * (container.clientWidth - image.width);
  var randomY = Math.random() * (container.clientHeight - image.height);
  
  image.style.left = randomX + 'px';
  image.style.top = randomY + 'px';
});
